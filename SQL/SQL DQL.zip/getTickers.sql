SELECT ticker_id, company_id, codigo_cvm, codigo_negociacao 
FROM tc_matrix.tickers
ORDER BY codigo_cvm
;