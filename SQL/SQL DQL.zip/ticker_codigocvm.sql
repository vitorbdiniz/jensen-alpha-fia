SELECT codigo_negociacao, codigo_cvm 
FROM tickers
;